package com.example.lms_prayekt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LmsPrayektApplicationTests {

    @Test
    void contextLoads() {
    }

}
