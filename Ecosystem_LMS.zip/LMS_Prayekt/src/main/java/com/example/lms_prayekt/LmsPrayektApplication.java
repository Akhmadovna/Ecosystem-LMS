package com.example.lms_prayekt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LmsPrayektApplication {

    public static void main(String[] args) {
        SpringApplication.run(LmsPrayektApplication.class, args);
    }

}
