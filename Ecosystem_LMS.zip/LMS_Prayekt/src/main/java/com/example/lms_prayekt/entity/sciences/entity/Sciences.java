package com.example.lms_prayekt.entity.sciences.entity;

import com.example.lms_prayekt.entity.lesson.entity.Lesson;
import com.example.lms_prayekt.entity.student.File;
import com.example.lms_prayekt.entity.teacher.Teacher;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;
@Getter
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Sciences {
    @Id
    private UUID id;
    private String name;
    private int freeLesson;
    private int accumulatedpoints;
    private int percentageoftotalscore;
    private String filname;
    @OneToMany(mappedBy = "sciences",fetch = FetchType.EAGER)
    private List<File>files;
     @OneToMany(mappedBy = "sciences",fetch = FetchType.LAZY)
    private List<Teacher>teachers;
    @OneToMany(mappedBy = "sciences",fetch = FetchType.EAGER)
   private List<Lesson>lessons;


    }

