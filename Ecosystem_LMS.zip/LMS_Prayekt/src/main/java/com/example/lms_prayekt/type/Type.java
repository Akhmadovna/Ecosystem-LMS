package com.example.lms_prayekt.type;

public enum Type {
    Teacher,Student,Admin
}
