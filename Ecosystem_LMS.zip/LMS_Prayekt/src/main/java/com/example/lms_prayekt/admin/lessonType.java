package com.example.lms_prayekt.admin;

public enum lessonType {
    practice,Lecture
}
